//
//  CollectionViewCell.swift
//  myCalendar
//
//  Created by eson on 2019/10/4.
//  Copyright © 2019 eson. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myLabel: UILabel!
    
}
