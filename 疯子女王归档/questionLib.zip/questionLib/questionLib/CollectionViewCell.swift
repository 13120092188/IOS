//
//  CollectionViewCell.swift
//  questionLib
//
//  Created by eson on 2019/10/5.
//  Copyright © 2019 eson. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myABCD: UILabel!
    
    @IBOutlet weak var myOptionText: UILabel!
}
