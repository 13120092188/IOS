//
//  ViewController.swift
//  questionLib
//
//  Created by eson on 2019/10/5.
//  Copyright © 2019 eson. All rights reserved.
//

import UIKit

struct QuestionItem {
    var question = ""
    var option = ["", "", "", "", "", ""]
    var answer = 0
}

var oneQuestion = QuestionItem(question: "“牛郎织女”的故事的故事是众口皆碑的神话传说，那你知道牛郎星是属于什么星座？", option: ["天琴座", "天鹰座", "金牛座", "狮子座"], answer: 2)
var twoQuestion = QuestionItem(question: "美丽奇特的“海市蜃楼”是光的折射产生的一种现象，它通常发生在什么时候？", option: ["春天", "夏天", "秋天", "冬天"], answer: 2)
var abcdText = ["A", "B", "C", "D", "E", "F"]
var allQuestions = [oneQuestion, twoQuestion, oneQuestion, twoQuestion, oneQuestion]
var oneGroup = allQuestions

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout  {
    
    @IBOutlet weak var mycollectionView: UICollectionView!

    @IBOutlet weak var myQuestion: UILabel!
    
    var index = 0
    var myAnswer:[Int:Int] = [0:-1, 1:-1, 2:-1, 3:-1, 4:-1]
    var submit = false
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return oneGroup[index].option.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        cell.myABCD.text = abcdText[indexPath.item]
        cell.myOptionText.text = oneGroup[index].option[indexPath.item]
        if submit{
            if myAnswer[index] == indexPath.item{
                if myAnswer[index] == oneGroup[index].answer{
                    cell.backgroundColor = UIColor.green
                }else{
                    cell.backgroundColor = UIColor.red
                }
            }else if oneGroup[index].answer == indexPath.item{
                if myAnswer[index] == -1{
                    cell.backgroundColor = UIColor.yellow
                }else{
                    cell.backgroundColor = UIColor.green
                }
            }else{
                cell.backgroundColor = mycollectionView.backgroundColor
            }
        }else{
            if myAnswer[index] == indexPath.item{
                cell.backgroundColor = UIColor.green
            }else{
                cell.backgroundColor = mycollectionView.backgroundColor
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if !submit{
            print("选中的是：",indexPath)
            let count = oneGroup[index].option.count - 1
            for i in 0...count{
                mycollectionView.cellForItem(at: [0,i])?.backgroundColor = mycollectionView.backgroundColor
            }
            mycollectionView.cellForItem(at: indexPath)?.backgroundColor = UIColor.green
            
            myAnswer[index] = indexPath.item
        }
    }
    
    @IBAction func lastQuestion(_ sender: Any) {
        if index > 0{
            index -= 1
        }
        print(index)
        myQuestion.text = oneGroup[index].question
        mycollectionView.reloadData()
    }
    
    @IBAction func nextQuestion(_ sender: Any) {
        if index < 4{
            index += 1
        }else{
            print(myAnswer)
        }
        print(index)
        myQuestion.text = oneGroup[index].question
        mycollectionView.reloadData()
    }
    
    @IBAction func submit(_ sender: Any) {
        submit = true
        index = 0
        mycollectionView.reloadData()
    }
    
    
    @IBAction func refresh(_ sender: Any) {
        index = 0
        myAnswer = [0:-1, 1:-1, 2:-1, 3:-1, 4:-1]
        submit = false
        mycollectionView.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myQuestion.text = oneGroup[index].question
    }


}

