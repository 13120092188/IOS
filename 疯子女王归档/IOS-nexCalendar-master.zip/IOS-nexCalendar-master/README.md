# IOS-nexCalendar
CS4298 group project 1

###Develop Environment:
- macOS 10.15
- xcode 11
- swiftUI (much easier than storyboard and UIkit)

- group repo✅ Current one


### Project scope
  - Ways of Promotion:
    - *Reading materials
    - Calendar function (Main Tab)
      - 
    - test / game system: 
      - MCQ (Tab)
        - take 5 random questions out of 20(q libraries)
        - Scoring 5 - 3stars; 3-4 2stars; 1-2 1stars; 0 - 0
      - Fill in the blanks 
        - question generator  
    - Settings (Tab)
      - Multilang
      - themes (dark - light)
      - background pictures
      - ...
  - calendar features: 
    - take pictures to set as background of the calendar.
    - multi language
    - import native event 


  - UI Design



  - Flow Design
    - test system


  - Promotion Videos
    - AE (After Effect)
  
